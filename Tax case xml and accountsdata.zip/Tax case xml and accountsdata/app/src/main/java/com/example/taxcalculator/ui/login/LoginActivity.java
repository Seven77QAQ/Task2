package com.example.taxcalculator.ui.login;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.taxcalculator.R;
import com.example.taxcalculator.RegisterActivity;
import com.example.taxcalculator.logic.AccountsDataInstance;
import com.example.taxcalculator.logic.ViewModelInstance;

public class LoginActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AccountsDataInstance.LoadModel(getApplicationContext());

        UserData user = AccountsDataInstance.Value.CurrentUser;
        if (user != null)
        {
            ViewModelInstance.LoadModel(getApplicationContext());
            Intent intent = new Intent(LoginActivity.this, ProjectActivity.class);
            startActivity(intent);
        }

        setContentView(R.layout.activity_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Tax Calculator");
        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
        final Button registerButton = findViewById(R.id.register);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        loadingProgressBar.setVisibility(View.GONE);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                if (AccountsDataInstance.Value.Login(usernameEditText.getText().toString(), passwordEditText.getText().toString()))
                {
                    AccountsDataInstance.SaveModel(getApplicationContext());
                    Toast.makeText(getApplicationContext(), AccountsDataInstance.Value.Message, Toast.LENGTH_SHORT).show();
                    ViewModelInstance.LoadModel(getApplicationContext());
                    loadingProgressBar.setVisibility(View.GONE);
                    Intent intent = new Intent(LoginActivity.this, ProjectActivity.class);
                    startActivity(intent);
                }else
                    {
                        Toast.makeText(getApplicationContext(), AccountsDataInstance.Value.Message, Toast.LENGTH_SHORT).show();
                        loadingProgressBar.setVisibility(View.GONE);
                    }
            }
        });
    }

    @Override
    protected void onRestart() {
        AccountsDataInstance.LoadModel(getApplicationContext());
        ViewModelInstance.LoadModel(getApplicationContext());
        ProgressBar loadingProgressBar = findViewById(R.id.loading);
        loadingProgressBar.setVisibility(View.GONE);
        super.onRestart();
    }
}
