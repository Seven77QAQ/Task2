package com.example.taxcalculator.logic;

import java.util.ArrayList;

public class ViewModel
{
    public String UserName;
    public String UserPassword;
    public String NickName;
    public ArrayList<Project> Projects;
    public Boolean Init;

    public void Init()
    {
        if (!Init) return;
        //do something
        Projects = new ArrayList<>();
        Init = true;
    }
}
