package com.example.taxcalculator.logic;

public enum  ObjectType
{
    CapitalGain, IncomeTax, Stock, TaxReturn
}
