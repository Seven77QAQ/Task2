package com.example.taxcalculator.logic;

import java.util.ArrayList;

public class ViewModel
{
    public String UserName;
    public String UserPassword;
    public String NickName;
    public ArrayList<Project> Projects;
    public int CurrentProjectPosition ;

    public ViewModel() {
        CurrentProjectPosition = -1;
        Projects = new ArrayList<>();
    }
}
