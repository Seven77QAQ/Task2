package com.example.taxcalculator.logic;

public class RegisterViewModel
{
    public String UserName;
    public String Password;
    public String ConfirmPassword;
    public String ErrorMessage;

    public RegisterViewModel(String userName, String password, String confirmPassword)
    {
        UserName = userName;
        Password = password;
        ConfirmPassword = confirmPassword;
        ErrorMessage = "";

        if (UserName.length() < 8 || Password.length() < 8 || confirmPassword.length() < 8)
        {
            ErrorMessage = "User name or password length must be greater than 8.";
        }

        if (!Password.equals(confirmPassword))
        {
            ErrorMessage = "Passwords not match.";
        }
    }
}
