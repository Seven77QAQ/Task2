package com.example.taxcalculator.logic;
import android.content.Context;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ViewModelInstance {
    public static ViewModel Value;
    private static Boolean Init = false;
    private static String FileName = "ViewModel.Json";

    public static void Init(Context context)
    {
        if (Init) return;
        LoadModel(context);
        Init = true;
    }

    public static void LoadModel(Context context)
    {
        String json = "";
        try {
            InputStream inputStream = context.openFileInput(FileName);
            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append("\n").append(receiveString);
                }

                inputStream.close();
                json = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            Value = new ViewModel();
            SaveModel(context);
            return;
        } catch (IOException e) {
            Value = new ViewModel();
            SaveModel(context);
            return;
        }
        Gson gson = new Gson();
        Value = gson.fromJson(json, ViewModel.class);
    }

    public static void SaveModel(Context context)
    {
        Gson gson = new Gson();
        String json = gson.toJson(Value);

        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(FileName, Context.MODE_PRIVATE));
            outputStreamWriter.write(json);
            outputStreamWriter.close();
        }
        catch (IOException e) {

        }
    }
}
