package com.example.taxcalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.taxcalculator.logic.RegisterViewModel;

public class RegisterActivity extends AppCompatActivity {

    private Button submit;
    private TextView userName;
    private TextView password;
    private TextView confirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Register your account");
        submit = findViewById(R.id.submit);
        userName = findViewById(R.id.username);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterViewModel viewModel = new RegisterViewModel(userName.getText().toString(), password.getText().toString(), confirmPassword.getText().toString());
            }
        });
    }


}
