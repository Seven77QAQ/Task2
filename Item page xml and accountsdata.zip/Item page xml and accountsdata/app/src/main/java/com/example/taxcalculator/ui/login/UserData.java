package com.example.taxcalculator.ui.login;

public class UserData
{
    public String UserId;
    public String UserName;
    public String Password;

    public UserData(String userId, String userName, String password) {
        UserId = userId;
        UserName = userName;
        Password = password;
    }

    public UserData() {
    }
}
