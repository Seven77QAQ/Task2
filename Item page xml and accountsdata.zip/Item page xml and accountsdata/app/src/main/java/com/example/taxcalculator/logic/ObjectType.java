package com.example.taxcalculator.logic;

public enum  ObjectType
{
    IncomeTax, TaxReturn, CapitalGain
}
