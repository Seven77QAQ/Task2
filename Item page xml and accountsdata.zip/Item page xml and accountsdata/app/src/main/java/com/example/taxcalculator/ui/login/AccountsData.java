package com.example.taxcalculator.ui.login;

import java.util.ArrayList;
import java.util.UUID;

public class AccountsData
{
    public ArrayList<UserData> Users;
    public String Message;
    public UserData CurrentUser;

    public AccountsData(ArrayList<UserData> users) {
        Users = users;
        Message = "";
        CurrentUser = null;
    }

    public AccountsData()
    {
        Users = new ArrayList<>();
        Message = "";
        CurrentUser = null;
    }

    public boolean Register(String userName, String password, String confirmPassword)
    {
        if (userName == null || password == null || confirmPassword == null)
        {
            Message = "User name and password cannot be empty.";
            return false;
        }

        if (userName.length() == 0 || password.length() == 0 || confirmPassword.length() == 0)
        {
            Message = "User name and password cannot be empty.";
            return false;
        }

        if (!password.equals(confirmPassword))
        {
            Message = "Passwords do not match.";
            return false;
        }

        if (userName.length() < 8 || password.length() < 8 )
        {
            Message = "User name or password length must be greater than 8.";
            return false;
        }

        if (Login(userName, password))
        {
            Message = "User name is already existed.";
            return false;
        }

        Users.add(new UserData(UUID.randomUUID().toString(), userName, password));
        Message = "Registration successful.";
        return true;
    }

    public boolean Login(String userName, String password)
    {
        if (userName == null || password == null)
        {
            Message = "User name and password cannot be empty.";
            return false;
        }

        if (userName.length() == 0 || password.length() == 0)
        {
            Message = "User name and password cannot be empty.";
            return false;
        }

        for (UserData user : Users)
        {
            if (user.UserName.equals(userName) && user.Password.equals(password))
            {
                CurrentUser = user;
                Message = "Login successful.";
                return true;
            }
        }

        Message = "Login failed. Please check username and password";
        return false;
    }

    public void SignOut()
    {
        CurrentUser = null;
    }
}
