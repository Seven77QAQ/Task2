package com.example.taxcalculator.logic;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.taxcalculator.R;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class ProjectRecycleViewAdapter extends RecyclerView.Adapter<ProjectRecycleViewAdapter.MyHolder>
{
    public ArrayList<Project> Projects;

    public ProjectRecycleViewAdapter(ArrayList<Project> projects)
    {
        Projects = projects;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.project_cell, parent, false);
        MyHolder myHolder = new MyHolder(view);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position)
    {
        DecimalFormat df = new DecimalFormat("#.##");
        holder.projectName.setText(Projects.get(position).Name);
        holder.income.setText(df.format(Projects.get(position).Income));
        holder.tax.setText(df.format(Projects.get(position).Tax));
        ViewGroup vg = ((ViewGroup)(holder.constraintLayout));
        if (position == ViewModelInstance.Value.CurrentProjectPosition)
        {
            holder.constraintLayout.setBackgroundColor(Color.parseColor("#6200EE"));
            SetColor(vg, "#ffffff");
        }
        else
        {
            holder.constraintLayout.setBackgroundColor(Color.parseColor("#ffffff"));
            SetColor(vg, "#000000");
        }
    }

    private void SetColor(ViewGroup vg, String color)
    {
        for (int i = 0; i < vg.getChildCount(); i ++)
        {
            View c = vg.getChildAt(i);
            if (c instanceof TextView)
            {
                ((TextView)c).setTextColor(Color.parseColor(color));
            }
        }
    }

    @Override
    public int getItemCount() {
        return Projects.size();
    }

    public class MyHolder extends  RecyclerView.ViewHolder {
        public TextView projectName;
        public  View constraintLayout;
        public TextView income;
        public TextView tax;
        public MyHolder(@NonNull final View itemView) {
            super(itemView);
            projectName = itemView.findViewById(R.id.ProjectName);
            constraintLayout = itemView.findViewById(R.id.constraint_layout);
            income = itemView.findViewById(R.id.Income);
            tax = itemView.findViewById(R.id.Tax);
            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    // get position
                    ViewModelInstance.Value.CurrentProjectPosition = getAdapterPosition();
                    notifyDataSetChanged();
                }
            });
        }
    }
}
