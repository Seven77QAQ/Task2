package com.example.taxcalculator.logic;

public class TaxReturn implements IElement
{
    private double income;

    public TaxReturn(double income) {
        this.income = income;
    }

    public TaxReturn(){}

    @Override
    public double Tax() {
        return -income;
    }

    @Override
    public double Income() {
        return -income;
    }
}
