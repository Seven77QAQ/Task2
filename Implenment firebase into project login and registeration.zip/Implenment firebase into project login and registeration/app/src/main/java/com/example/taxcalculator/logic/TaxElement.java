package com.example.taxcalculator.logic;

public class TaxElement
{
    public String Name;
    public double Income;
    public double Tax;
    public String Type;

    public TaxElement(String name, double income, String type) {
        Name = name;
        Income = income;
        Type = type;
        switch (type)
        {
            case "CapitalGain":
                Tax = 0.5 * Income;
                break;
            case "TaxReturn":
                Income = -Income;
                Tax = Income;
                break;
            default:
                if (Income >= 180001)
                {
                    Tax = 54097 + (Income-180000) * 0.45;
                    return;
                }

                if (Income >= 90001)
                {
                    Tax = 20797 + (Income-90000) * 0.37;
                    return;
                }

                if (Income >= 37001)
                {
                    Tax = 3572 + (Income-37000) * 0.325;
                    return;
                }

                if (Income >= 37001)
                {
                    Tax = 3572 + (Income-37000) * 0.325;
                    return;
                }

                if (Income >= 18201)
                {
                    Tax = (Income-18200) * 0.19;
                    return;
                }
                Tax = 0;
        }
    }

    public TaxElement(){}
}
