package com.example.taxcalculator.logic;

public class CapitalGain implements IElement
{
    private double income;

    public CapitalGain(double income) {
        this.income = income;
    }

    public CapitalGain(){}

    @Override
    public double Tax() {
        return income * 0.5;
    }

    @Override
    public double Income() {
        return income;
    }
}
