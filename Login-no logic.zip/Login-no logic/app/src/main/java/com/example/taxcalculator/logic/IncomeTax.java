package com.example.taxcalculator.logic;

public class IncomeTax implements IElement {

    private double income;

    public IncomeTax(double income) {
        this.income = income;
    }

    public IncomeTax(){}

    @Override
    public double Tax() {
        if (income >= 180001)
        {
            return 54097 + (income-180000) * 0.45;
        }

        if (income >= 90001)
        {
            return 20797 + (income-90000) * 0.37;
        }

        if (income >= 37001)
        {
            return 3572 + (income-37000) * 0.325;
        }

        if (income >= 37001)
        {
            return 3572 + (income-37000) * 0.325;
        }

        if (income >= 18201)
        {
            return (income-18200) * 0.19;
        }

        return 0;
    }

    @Override
    public double Income() {
        return income;
    }
}
