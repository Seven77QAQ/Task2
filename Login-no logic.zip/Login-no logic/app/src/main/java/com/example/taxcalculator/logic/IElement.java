package com.example.taxcalculator.logic;

public interface IElement
{
    double Tax();
    double Income();
}
