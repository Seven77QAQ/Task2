package com.example.taxcalculator.logic;

public class ViewModelInstance {
    public static ViewModel Value;
    private static Boolean Init = false;

    public static void Init()
    {
        if (Init) return;
        //do something
        Value = new ViewModel();
        Value.Projects.add(new Project("Project 1"));
        Value.Projects.add(new Project("Project 2"));
        Value.Projects.add(new Project("Project 3"));
        Init = true;
    }
}
