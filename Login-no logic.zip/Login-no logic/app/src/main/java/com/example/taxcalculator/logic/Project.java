package com.example.taxcalculator.logic;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.UUID;
public class Project
{
    //public String Id;
    //public String UserId;
    public String Name;
    public double Income;
    public double Tax;
    public ArrayList<IElement> Elements;

    public Project(String name)
    {
        //Id = UUID.randomUUID().toString();
        //UserId = userId;
        Name = name;
        Elements = new ArrayList<>();
        Income = 0;
        Tax = 0;
    }

    public Project()
    {
        Name = "";
        Elements = new ArrayList<>();
        Income = 0;
        Tax = 0;
    }

    public void AddElement(IElement element)
    {
        Elements.add(element);
    }

    public void RemoveElement(int pos)
    {
        Elements.remove(pos);
    }

    public void Calculate()
    {
        for (IElement element : Elements)
        {
            Income += element.Income();
            Tax += element.Tax();
        }
    }

    public String Json()
    {
        Gson gson = new Gson();
        String json = gson.toJson(this);
        return json;
    }

    public static Project LoadFromJson(String json)
    {
        Gson gson = new Gson();
        return gson.fromJson(json, Project.class);
    }
}
