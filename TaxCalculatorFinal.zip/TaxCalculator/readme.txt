Team Member:
Student name: Qikun Shen Student ID:219083119
Student name: Sizuo Liu Student ID:219083084

Overview:
Our app(Bull Tax Calculator) is mainly used for bookkeeping, whether it is company tax Calculate or personal bookkeeping, you can use this tax Calculator. You can manually add your case and calculate your after-tax income based on a certain tax rate relationship. 

GitHub link: