package com.example.taxcalculator.logic;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.taxcalculator.R;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ElementRecycleViewAdapter extends RecyclerView.Adapter<ElementRecycleViewAdapter.MyHolder>
{
    public ArrayList<TaxElement> Elements;

    public ElementRecycleViewAdapter(ArrayList<TaxElement> elements) {
        Elements = elements;
    }
    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.element_cell, parent, false);
        MyHolder myHolder = new MyHolder(view);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position)
    {
        DecimalFormat df = new DecimalFormat("#.##");
        holder.elementName.setText(Elements.get(position).Name);
        holder.income.setText(df.format(Elements.get(position).Income));
        holder.type.setText(Elements.get(position).Type);
        ViewGroup vg = ((ViewGroup)(holder.constraintLayout));
        if (position == ViewModelInstance.Value.CurrentElementPosition)
        {
            holder.constraintLayout.setBackgroundColor(Color.parseColor("#6200EE"));
            SetColor(vg, "#ffffff");
        }
        else
        {
            holder.constraintLayout.setBackgroundColor(Color.parseColor("#ffffff"));
            SetColor(vg, "#000000");
        }
    }

    private void SetColor(ViewGroup vg, String color)
    {
        for (int i = 0; i < vg.getChildCount(); i ++)
        {
            View c = vg.getChildAt(i);
            if (c instanceof TextView)
            {
                ((TextView)c).setTextColor(Color.parseColor(color));
            }
        }
    }

    @Override
    public int getItemCount() {
        return Elements.size();
    }

    public class MyHolder extends  RecyclerView.ViewHolder {
        public TextView elementName;
        public  View constraintLayout;
        public TextView income;
        public TextView type;
        public MyHolder(@NonNull final View itemView) {
            super(itemView);
            elementName = itemView.findViewById(R.id.ElementName);
            constraintLayout = itemView.findViewById(R.id.constraint_layout);
            income = itemView.findViewById(R.id.Income);
            type = itemView.findViewById(R.id.Type);
            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    // get position
                    ViewModelInstance.Value.CurrentElementPosition = getAdapterPosition();
                    notifyDataSetChanged();
                }
            });
        }
    }
}
