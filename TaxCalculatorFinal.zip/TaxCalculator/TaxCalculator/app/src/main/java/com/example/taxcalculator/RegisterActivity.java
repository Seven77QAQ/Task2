package com.example.taxcalculator;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.example.taxcalculator.logic.AccountsDataInstance;
import com.example.taxcalculator.ui.login.LoginActivity;

public class RegisterActivity extends AppCompatActivity {

    private Button submit;
    private TextView userName;
    private TextView password;
    private TextView confirmPassword;
    private ProgressBar loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Register your account");
        submit = findViewById(R.id.submit);
        userName = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loading = findViewById(R.id.loading);
        loading.setVisibility(View.GONE);
        confirmPassword = findViewById(R.id.confirmPassword);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loading.setVisibility(View.VISIBLE);
                if (AccountsDataInstance.Value.Register(userName.getText().toString(), password.getText().toString(), confirmPassword.getText().toString()))
                {
                    loading.setVisibility(View.GONE);
                    AccountsDataInstance.SaveModel(getApplicationContext());
                    Toast.makeText(getApplicationContext(), AccountsDataInstance.Value.Message, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                }else
                    {
                        loading.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), AccountsDataInstance.Value.Message, Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
}
