package com.example.taxcalculator.ProjectActivities;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.taxcalculator.R;
import com.example.taxcalculator.logic.ElementRecycleViewAdapter;
import com.example.taxcalculator.logic.ObjectType;
import com.example.taxcalculator.logic.Project;
import com.example.taxcalculator.logic.TaxElement;
import com.example.taxcalculator.logic.ViewModelInstance;
import com.google.gson.Gson;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ElementActivity extends AppCompatActivity {

    private EditText projectName;
    private EditText elementName;
    private EditText elementIncome;
    private Spinner type;
    private TextView income;
    private TextView tax;
    private RecyclerView elementsView;
    private RecyclerView.LayoutManager layoutManager;
    private ElementRecycleViewAdapter adapterElements;

    private Button add;
    private Button del;
    private Button submit;
    private Project project;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_element);
        Init(savedInstanceState);
    }

    private void UpdateProjectView()
    {
        project.Calculate();
        adapterElements.notifyDataSetChanged();
        DecimalFormat df = new DecimalFormat("#.##");
        projectName.setText(project.Name);
        income.setText(df.format(project.Income));
        tax.setText(df.format(project.Tax));
    }

    private void Init(Bundle savedInstanceState)
    {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Manage my case");
        projectName = findViewById(R.id.ProjectName);
        elementName = findViewById(R.id.ElementName);
        elementIncome = findViewById(R.id.ElementIncome);
        elementsView = findViewById(R.id.recyclerViewElement);
        add = findViewById(R.id.AddElement);
        del = findViewById(R.id.DeleteElement);
        submit = findViewById(R.id.Submit);
        type = findViewById(R.id.Type);
        income = findViewById(R.id.Income);
        tax = findViewById(R.id.Tax);
        String json = "";
        project = new Project();
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras != null)  json = extras.getString("SelectedProject");
        }
        Gson gson = new Gson();
        if (json.length() > 5) project =gson.fromJson(json, Project.class);
        DecimalFormat df = new DecimalFormat("#.##");
        projectName.setText(project.Name);
        income.setText(df.format(project.Income));
        tax.setText(df.format(project.Tax));
        elementName.setText("");
        elementIncome.setText("");
        List<ObjectType> enumValues = Arrays.asList(ObjectType.values());
        ArrayList<String> opts = new ArrayList<>();
        for (ObjectType type : enumValues)
        {
            opts.add(type.toString());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, opts);
        type.setAdapter(adapter);
        layoutManager = new GridLayoutManager(this, 1);
        elementsView.setLayoutManager(layoutManager);
        adapterElements = new ElementRecycleViewAdapter(project.Elements);
        elementsView.setAdapter(adapterElements);
        elementsView.setHasFixedSize(true);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ViewModelInstance.Value.CurrentElementPosition != -1)
                {
                    int pos = ViewModelInstance.Value.CurrentElementPosition;
                    project.Elements.remove(pos);
                    UpdateProjectView();
                    ViewModelInstance.Value.CurrentElementPosition = -1;
                }
            }
        });

        add.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                ViewModelInstance.Value.CurrentElementPosition = -1;
                String elementNameString = elementName.getText().toString();
                String elementIncomeString = elementIncome.getText().toString();
                String elementTypeString = type.getSelectedItem().toString();
                project.Name = projectName.getText().toString();
                elementName.setText("");
                elementIncome.setText("");
                if (elementNameString.length() > 1 && elementIncomeString.length()> 1)
                {
                    project.Elements.add(new TaxElement(elementNameString, Double.parseDouble(elementIncomeString), elementTypeString));
                    UpdateProjectView();
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (ViewModelInstance.Value.CurrentProjectPosition != -1)
                {
                    ViewModelInstance.Value.Projects.remove(ViewModelInstance.Value.CurrentProjectPosition);
                    ViewModelInstance.Value.Projects.add(project);
                    ViewModelInstance.Value.CurrentProjectPosition = ViewModelInstance.Value.Projects.size() - 1;
                }else
                    {
                        ViewModelInstance.Value.Projects.add(project);
                        ViewModelInstance.Value.CurrentProjectPosition = ViewModelInstance.Value.Projects.size() - 1;
                    }
                ViewModelInstance.SaveModel(getApplicationContext());
                Intent intent = new Intent(ElementActivity.this, ProjectActivity.class);
                startActivity(intent);
            }
        });
    }
}
