package com.example.taxcalculator.ProjectActivities;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.taxcalculator.R;
import com.example.taxcalculator.logic.AccountsDataInstance;
import com.example.taxcalculator.logic.ProjectRecycleViewAdapter;
import com.example.taxcalculator.logic.ViewModelInstance;
import com.example.taxcalculator.ui.login.LoginActivity;
import com.google.gson.Gson;

public class ProjectActivity extends AppCompatActivity
{
    private RecyclerView projectsView;
    private RecyclerView.LayoutManager layoutManager;
    private ProjectRecycleViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);
        Init();
    }

    @Override
    protected void onRestart() {
        adapter.notifyDataSetChanged();
        super.onRestart();
    }

    private void Init()
    {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Cases");
        Button addProject = findViewById(R.id.AddProject);
        Button openProject = findViewById(R.id.OpenProject);
        Button deleteProject = findViewById(R.id.DeleteProject);
        Button logout = findViewById(R.id.Logout);
        final TextView noProject = findViewById(R.id.NoProjectFound);
        final ImageButton image = findViewById(R.id.imageView);
        if (ViewModelInstance.Value.Projects.size() > 0)
        {
            noProject.setVisibility(View.GONE);
            image.setVisibility(View.GONE);
        }
        else
        {
            noProject.setVisibility(View.VISIBLE);
            image.setVisibility(View.VISIBLE);
        }
        projectsView = findViewById(R.id.ProjectRecycleView);
        layoutManager = new GridLayoutManager(this, 1);
        projectsView.setLayoutManager(layoutManager);
        adapter = new ProjectRecycleViewAdapter(ViewModelInstance.Value.Projects);
        projectsView.setAdapter(adapter);
        projectsView.setHasFixedSize(true);
        addProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewModelInstance.Value.CurrentProjectPosition = -1;
                Intent intent = new Intent(ProjectActivity.this, ElementActivity.class);
                startActivity(intent);
            }
        });
        openProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ViewModelInstance.Value.CurrentProjectPosition != -1)
                {
                    Intent intent = new Intent(ProjectActivity.this, ElementActivity.class);
                    Gson gson = new Gson();
                    String json = gson.toJson(ViewModelInstance.Value.Projects.get(ViewModelInstance.Value.CurrentProjectPosition));
                    intent.putExtra("SelectedProject", json);
                    startActivity(intent);
                }
            }
        });
        deleteProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ViewModelInstance.Value.CurrentProjectPosition != -1)
                {
                    ViewModelInstance.Value.Projects.remove(ViewModelInstance.Value.CurrentProjectPosition);
                    ViewModelInstance.Value.CurrentProjectPosition = -1;
                    adapter.notifyDataSetChanged();
                    ViewModelInstance.SaveModel(getApplicationContext());
                    if (ViewModelInstance.Value.Projects.size() > 0)
                    {
                        noProject.setVisibility(View.GONE);
                        image.setVisibility(View.GONE);
                    }
                    else
                    {
                        noProject.setVisibility(View.VISIBLE);
                        image.setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AccountsDataInstance.Value.SignOut();
                AccountsDataInstance.SaveModel(getApplicationContext());
                Intent intent = new Intent(ProjectActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewModelInstance.Value.CurrentProjectPosition = -1;
                Intent intent = new Intent(ProjectActivity.this, ElementActivity.class);
                startActivity(intent);
            }
        });
    }
}
