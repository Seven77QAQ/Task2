package com.example.taxcalculator.logic;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class UserData
{
    public String Data;

    public UserData(String dataJson) {
        Data = dataJson;
    }

    public UserData(){}
}
