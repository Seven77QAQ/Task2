package com.example.taxcalculator.logic;

import java.util.ArrayList;

public class ViewModel
{
    public String UserId;
    public ArrayList<Project> Projects;
    public int CurrentProjectPosition ;
    public int CurrentElementPosition ;

    public ViewModel() {
        UserId = "";
        CurrentProjectPosition = -1;
        CurrentElementPosition = -1;
        Projects = new ArrayList<>();
    }
}
